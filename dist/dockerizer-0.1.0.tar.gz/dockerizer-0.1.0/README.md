# Dockerizer
A command-line tool to dockerize your applications in a jiffy.
